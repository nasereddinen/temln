<template>
    <GSTC/>
    <GridCalendar/>

</template>
<script>
import GSTC from '../components/GSTC.vue';
import GridCalendar from '../components/GridCalendar.vue';
export default {
    components: {
        GSTC,
        
    
    }
}  
</script>
```
