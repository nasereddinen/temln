<template>
    <div>
      <div class="scheduler">
        <div class="scheduler-header">
          <!-- Add header elements for navigation and controls -->
          <button @click="goToPreviousDay">Previous</button>
          <h2>{{ currentDate }}</h2>
          <button @click="goToNextDay">Next</button>
        </div>
        <div class="scheduler-body">
          <!-- Add the scheduler grid and display events -->
          <div class="scheduler-grid">
            <!-- Display time slots or intervals -->
            <div class="time-slot"></div>
            <div class="time-slot" v-for="timeSlot in timeSlots" :key="timeSlot">{{ timeSlot }}</div>
          </div>
          <div class="scheduler-events">
            <!-- Display events for the current day -->
            <div v-for="event in getEventsForCurrentDay" :key="event.id" class="event" :style="eventStyle(event)">
              <div class="event-title">{{ event.title }}</div>
              <div class="event-time">{{ event.start }} - {{ event.end }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'GridCalendar',
    data() {
      return {
        currentDate: new Date().toLocaleDateString(), // Store the current date
        events: [
          {
            id: 1,
            title: 'Event 1',
            start: new Date('2023-06-01T09:00:00'),
            end: new Date('2023-06-01T10:00:00'),
          },
          {
            id: 2,
            title: 'Event 2',
            start: new Date('2023-06-02T14:00:00'),
            end: new Date('2023-06-02T16:00:00'),
          },
          // Add more events as needed
        ],
        timeSlots: [
          '09:00 AM',
          '10:00 AM',
          '11:00 AM',
          '12:00 PM',
          '01:00 PM',
          '02:00 PM',
          '03:00 PM',
          '04:00 PM',
          '05:00 PM',
          '06:00 PM',
        ],
      };
    },
    computed: {
      getEventsForCurrentDay() {
        const currentDay = new Date().toLocaleDateString();
        return this.events.filter(
          (event) => event.start.toLocaleDateString() === currentDay
        );
      },
    },
    methods: {
      goToPreviousDay() {
        const previousDay = new Date();
        previousDay.setDate(previousDay.getDate() - 1);
        this.currentDate = previousDay.toLocaleDateString();
      },
      goToNextDay() {
        const nextDay = new Date();
        nextDay.setDate(nextDay.getDate() + 1);
        this.currentDate = nextDay.toLocaleDateString();
      },
      eventStyle(event) {
        const startHour = event.start.getHours();
        const startMinute = event.start.getMinutes();
        const endHour = event.end.getHours();
        const endMinute = event.end.getMinutes();
        const totalMinutes = (endHour - startHour) * 60 + (endMinute - startMinute);
        const top = (startHour - 9) * 60 + startMinute;
        const height = totalMinutes;
  
        return {
          top: `${top}px`,
          height: `${height}px`,
        };
      },
    },
  };
    </script>   
    <style scoped>
    .scheduler {
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
    }
    .scheduler-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 1rem;
    }
    .scheduler-body {
      flex: 1;
      display: flex;
      padding: 1rem;
    }
    .scheduler-grid {
      flex: 1;
      display: flex;
      flex-direction: column;
      border-right: 1px solid #ccc;
    }
    .time-slot {
      flex: 1;
      border-bottom: 1px solid #ccc;
      padding: 0.5rem;
      text-align: center;
    }
    .scheduler-events {
      flex: 4;
      display: flex;
      flex-direction: column;
      padding: 0 1rem;
    }
    .event {
      border: 1px solid #ccc;
      border-radius: 0.5rem;
      padding: 0.5rem;
      margin-bottom: 0.5rem;
    }
    .event-title {
      font-weight: bold;
    }
    .event-time {
      font-size: 0.8rem;
    }
    </style>
  