<template>
  <div class="wrapper">
    <p>
      Timeline test 2
    </p>
    <select v-model="selectedDate">
      <option v-for="date in dateoption" :key="date" :value="date">
        {{ date }}
      </option>
      </select>
  <button @click="selectInitailDate">Go to selected date</button>
    <div id="visualization"></div>
    <div id="calendar">
    </div>
    <button @click="goToNextDay">Move to Next Day</button>
  </div>
</template>

<script>
import { Timeline } from 'vis-timeline/standalone';
import axios from 'axios';

export default {
  name: 'GSTC',
  components: {},
  data() {
    return {
      currentDate: new Date(),
      initialeDate : new Date(),
      selectedDate: "2023-06-01",
      dateoption :[
          '2023-06-01',
          '2023-06-02',
          '2023-06-03',
      ],

      
      items: [
        {
          id: 1,
          group: 1,
          content: 'item 1',
          start: new Date(new Date().getTime() + 10000000),
          end: new Date(new Date().getTime() + 20000000),
        },
        {
          id: 2,
          group: 0,
          content: 'item 2',
          start: new Date(new Date().getTime() + 10000000),
          end: new Date(new Date().getTime() + 20000000),
        },
      ],
      groups: [
        {
          id: 0,
          content: 'Tech 1',
          className: 'vis-h0',
        },
        {
          id: 1,
          content: 'Tech 2',
          className: 'vis-h0',
        },
      ],
      // timeline options
      options: {
        stack: true,
        start: "2023-06-01 00:00:00",
        end: "2023-06-03 00:00:00",
        editable: true,
        selectable: true,
        groupEditable: true,
        groupOrder: 'content', // groupOrder can be a property name or a sorting function
        groupOrderSwap: function (a, b, groups) {
          var v = a.value;
          a.value = b.value;
          b.value = v;
        },
        groupTemplate: function (group) {
          return group.content + ' (' + group.items.length + ' items)';
        },
        itemTemplate: function (item) {
          return item.content + ' (' + item.group.content + ')';
        },
    
        editable: {
          add: true, // add new items by double tapping
          updateTime: true, // drag items horizontally
          updateGroup: true, // drag items from one group to another
          remove: true, // delete an item by tapping the delete button top right
          overrideItems: false, // allow these options to override item.editable
        },
        timeAxis: {
          scale: 'hour',
          step: 1,
        },
        orientation: { axis: 'both' },
        zoomMax: 1000 * 60 * 60 * 24, // about 31 days
        zoomMin: 1000 * 60 * 60 * 24 * 1, // about 1 day

        onAdd: function (item, callback) {
          item.content = prompt('Enter text content for new item:', item.content);
          if (item.content != null) {
            callback(item); // send back adjusted new item
          } else {
            callback(null); // cancel item creation
          }
        },

        onUpdate: function (item, callback) {
          item.content = prompt('Edit items text:', item.content);
          if (item.content != null) {
            callback(item); // send back adjusted item
          } else {
            callback(null); // cancel updating the item
          }
        },
        onMove: function (item, callback) {
          if (item.content != null) {
          } else {
            callback(null); // cancel updating the item
          }
        },
      },
      dataLoaded: null,
      timeline: null,
    };
  },
  async mounted() {
    await this.dataLoaded;
    
    // Create a Timeline
    this.timeline = new Timeline(document.getElementById('visualization'));
    this.timeline.setOptions(this.options);
    this.timeline.setGroups(this.groups);
    this.timeline.setItems(this.items);


  },
  methods: {
    goToNextDay() {
      const nextDay = new Date(this.currentDate);
      nextDay.setDate(nextDay.getDate() + 1);
      this.currentDate = nextDay.toLocaleDateString();
    },

    selectInitailDate(){
      const selectedDate = new Date(this.selectedDate);
      const startDate = new Date(selectedDate);
      startDate.setHours(0, 0, 0, 0); // Set time to the beginning of the day
      const endDate = new Date(selectedDate);
      endDate.setHours(23, 59, 59, 999); // Set time to the end of the day

      this.options.start = startDate;
      this.options.end = endDate;
      

      // Update the timeline

      this.updateTimeline();
    

    },

    updateTimeline() {
      //destroy timeline
      this.timeline.destroy();
      // Create a Timeline
      this.timeline = new Timeline(document.getElementById('visualization'));
      this.timeline.setOptions(this.options);
      this.timeline.setGroups(this.groups);
      this.timeline.setItems(this.items);
    },
    
  },
};
</script>

<style>
  .vis-time-axis .vis-grid.vis-odd {
    background: #f5f5f5;
  }
  .vis-time-axis .vis-grid.vis-saturday,
  .vis-time-axis .vis-grid.vis-sunday {
    background: gray;
  }
  .vis-time-axis .vis-text.vis-saturday,
  .vis-time-axis .vis-text.vis-sunday {
    color: white;
  }
  .vis-item {
    background-color: #d6e6ff;
    border-color: #1371fe;
    color: #0155d3;
    border-left-width: 3px;
    border-left-style: solid;
    font-weight: 500;
    opacity: 0.8;
    font-size: 13px;
    height: 55px;
  }
  .vis-h0 .vis-h01 .vis-h15 .vis-h16 {
    color: blue !important;
    height: 100px;
    text-align: center;
  }
</style>
